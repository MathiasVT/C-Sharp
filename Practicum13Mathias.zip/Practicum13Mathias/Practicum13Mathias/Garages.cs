﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Practicum13Mathias
{
    class Garages
    {
        public Garages()
        {
            AutoGarages = new List<Garage>();
        }
        public List<Garage> AutoGarages { get; set; }
    }
}
